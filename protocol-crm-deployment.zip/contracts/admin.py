from django.contrib import admin
from .models import Contract

admin.site.register(Contract)

