from django.apps import AppConfig


class OwnersConfig(AppConfig):
    name = 'owners'
