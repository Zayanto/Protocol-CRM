from django.apps import AppConfig


class SmsConfig(AppConfig):
    name = 'sms'
